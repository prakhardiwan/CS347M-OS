#include "types.h"
#include "stat.h"
#include "user.h"


int
main(int argc, char *argv[])
{
  // Add in your code here using the hello() system call 
  hello();
  exit();
}
